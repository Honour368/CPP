// Handling user commands

#include <iostream>
#include <string>
using namespace std;

int myNumbers[100];
int myCount = 0;

void add() {
	int x;
	cin >> x;
	myNumbers[myCount] = x;
	myCount++;
}

int main() {
	string input;
	cin >> input;
	while (input != "exit") {
		if (input == "add") {
			add();
		}
		cin >> input;
	}
	return 0;
}